from telethon import TelegramClient, events
import asyncio
from datetime import datetime

api_id = 27968725
api_hash = '853ecb50fa160b9c2c359c97b9f4e69c'

# sendto = "Kartik_J12"
username = "Rishi"

client = TelegramClient(username, api_id, api_hash)

msg = """*Please book plot no 308

*Project name- riyasat eco park -1

Associate name  = rishabh yadav 

*Clint name- Ram Pratap meena

*Rera no. - 2021-2549

Team - (fire)  Abps Ramsingh ji
"""

hours = 12
minutes = 40
seconds = 59
microseconds = 960000


async def find_group_by_name():
    # Get a list of your dialogs (chats)
    dialogs = await client.get_dialogs()
    
    # Loop through the dialogs to find the group by name
    for dialog in dialogs:
        # if dialog.name == "Arvind Alwar":
        if dialog.name == "RIYASAT Group":
            return dialog
    
    # If the group is not found, return None or handle accordingly
    return None

async def send_message():
    sendto = await find_group_by_name()

    if sendto is None:
        print("Group not found")
        return

    print("Group found, entering in loop...")
    while True:
        now = datetime.now()
        # and now.minute == 43
        if now.hour == 12 and now.minute == 59 and now.second == 59 and now.microsecond >= 960000:        
            await client.send_message(entity=sendto,message=msg)
            break

    
    print("Message sent successfully!")
    # Disconnect the client
    await client.disconnect()

with client:
    client.loop.run_until_complete(send_message())