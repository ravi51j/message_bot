from telethon import TelegramClient, events
import asyncio
from datetime import datetime
import threading

api_id = 27968725
api_hash = '853ecb50fa160b9c2c359c97b9f4e69c'

# sendto = "Kartik_J12"
username = "Rishi"

client = TelegramClient(username, api_id, api_hash)

msg = """*Please book plot no 308

*Project name- riyasat eco park -1

Associate name  = rishabh yadav 

*Clint name- Ram Pratap meena

*Rera no. - 2021-2549

Team - (fire)  Abps Ramsingh ji
"""

hours = 13
minutes = 27
seconds = 59
microseconds = 960000



async def find_group_by_name():
    # Get a list of your dialogs (chats)
    dialogs = await client.get_dialogs()
    
    # Loop through the dialogs to find the group by name
    for dialog in dialogs:
        if dialog.name == "Arvind Alwar":
        # if dialog.name == "RIYASAT Group":
            return dialog
    
    # If the group is not found, return None or handle accordingly
    return None

async def send_message(delay, index, sendto):
    global hours
    global minutes
    global seconds
    global microseconds

    # sendto = await find_group_by_name()

    if sendto is None:
        print("Group not found")
        return

    print(index, "Group found, entering in loop...")
    while True:
        now = datetime.now()
        # and now.minute == 43
        # print(microseconds + (10000 * delay))
        if now.hour == hours and now.minute == minutes and now.second == seconds and now.microsecond >= (microseconds + (10000 * delay)):        
            await client.send_message(entity=sendto,message=msg)
            break

    print(index, "Message sent successfully!")
    # Disconnect the client
    await client.disconnect()

def send_message_1():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    loop.run_until_complete(send_message(0,0))
    loop.close()

    # asyncio.run(send_message(0, 0))

def send_message_2():
    asyncio.run(send_message(10, 1))

def send_message_3():
    asyncio.run(send_message(20, 2))

async def send_all_messages():
    sendto = await find_group_by_name()

    tasks = []
    for i in range(3):
        task = asyncio.create_task(send_message(i, i, sendto))
        tasks.append(task)

    await asyncio.gather(*tasks)

    # await send_message(0, 0)
    # await send_message(10, 1)
    # await send_message(20, 2)
     
    # t1 = threading.Thread(target=send_message_1)
    # t1.start()
    # t2 = threading.Thread(target=send_message_2)
    # t2.start()
    # t3 = threading.Thread(target=send_message_3)
    # t3.start()

    # t1.join()
    # t2.join()
    # t3.join()

with client:
    client.loop.run_until_complete(send_all_messages())

# with client:
#     # send_all_messages()
#     client.loop.run_until_complete(send_all_messages())
#     # client.run_until_disconnected()
